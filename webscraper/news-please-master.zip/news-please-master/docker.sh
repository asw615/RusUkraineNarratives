#!/bin/sh

cd /news-please/newsplease
python3 __main__.py -c ./config